import { sql } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
  decimal,
  boolean,
  uuid,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session storage table - mandatory for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table - mandatory for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: varchar("role").default("customer"), // customer, admin, driver
  phone: varchar("phone"),
  address: text("address"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const categories = pgTable("categories", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  nameAr: varchar("name_ar").notNull(),
  icon: varchar("icon").notNull(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const restaurants = pgTable("restaurants", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  nameAr: varchar("name_ar").notNull(),
  description: text("description"),
  descriptionAr: text("description_ar"),
  image: varchar("image"),
  coverImage: varchar("cover_image"),
  categoryId: uuid("category_id").references(() => categories.id),
  rating: decimal("rating", { precision: 3, scale: 2 }).default("0"),
  reviewCount: integer("review_count").default(0),
  deliveryTime: varchar("delivery_time"), // "40-60 دقيقة"
  minimumOrder: integer("minimum_order"), // in Yemeni Rial
  deliveryFee: integer("delivery_fee"), // in Yemeni Rial
  isOpen: boolean("is_open").default(true),
  ownerId: varchar("owner_id").references(() => users.id),
  address: text("address"),
  phone: varchar("phone"),
  latitude: decimal("latitude", { precision: 10, scale: 8 }),
  longitude: decimal("longitude", { precision: 11, scale: 8 }),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const menuItems = pgTable("menu_items", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  restaurantId: uuid("restaurant_id").references(() => restaurants.id),
  name: varchar("name").notNull(),
  nameAr: varchar("name_ar").notNull(),
  description: text("description"),
  descriptionAr: text("description_ar"),
  price: integer("price").notNull(), // in Yemeni Rial
  image: varchar("image"),
  category: varchar("category"), // العروض، وجبات رمضان، المقبلات، المشروبات
  isAvailable: boolean("is_available").default(true),
  isSpecialOffer: boolean("is_special_offer").default(false),
  originalPrice: integer("original_price"), // for discounted items
  servingSize: varchar("serving_size"), // حجم الوجبة
  preparationTime: varchar("preparation_time"), // وقت التحضير
  ingredients: text("ingredients"), // المكونات
  calories: integer("calories"), // السعرات الحرارية
  isPopular: boolean("is_popular").default(false), // وجبة شعبية
  tags: text("tags").array(), // وسوم إضافية
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const orders = pgTable("orders", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  orderNumber: varchar("order_number").unique().notNull(),
  customerId: varchar("customer_id").references(() => users.id),
  restaurantId: uuid("restaurant_id").references(() => restaurants.id),
  driverId: varchar("driver_id").references(() => users.id),
  status: varchar("status").notNull().default("pending"), // pending, confirmed, preparing, out_for_delivery, delivered, cancelled
  subtotal: integer("subtotal").notNull(),
  deliveryFee: integer("delivery_fee").notNull(),
  discount: integer("discount").default(0),
  total: integer("total").notNull(),
  paymentMethod: varchar("payment_method").notNull(), // cash, electronic, wallet
  deliveryAddress: text("delivery_address").notNull(),
  deliveryLatitude: decimal("delivery_latitude", { precision: 10, scale: 8 }),
  deliveryLongitude: decimal("delivery_longitude", { precision: 11, scale: 8 }),
  customerNotes: text("customer_notes"),
  estimatedDeliveryTime: timestamp("estimated_delivery_time"),
  deliveredAt: timestamp("delivered_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const orderItems = pgTable("order_items", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  orderId: uuid("order_id").references(() => orders.id),
  menuItemId: uuid("menu_item_id").references(() => menuItems.id),
  quantity: integer("quantity").notNull(),
  price: integer("price").notNull(), // price at time of order
  notes: text("notes"),
});

export const offers = pgTable("offers", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  title: varchar("title").notNull(),
  titleAr: varchar("title_ar").notNull(),
  description: text("description"),
  descriptionAr: text("description_ar"),
  image: varchar("image"),
  discountType: varchar("discount_type").notNull(), // percentage, fixed_amount, free_delivery
  discountValue: integer("discount_value").notNull(),
  minimumOrder: integer("minimum_order"),
  restaurantId: uuid("restaurant_id").references(() => restaurants.id),
  isActive: boolean("is_active").default(true),
  startDate: timestamp("start_date").defaultNow(),
  endDate: timestamp("end_date"),
  priority: integer("priority").default(0), // أولوية العرض
  usageLimit: integer("usage_limit"), // حد الاستخدام
  usedCount: integer("used_count").default(0), // عدد المرات المستخدمة
  createdAt: timestamp("created_at").defaultNow(),
});

// جدول الصور والملفات
export const mediaFiles = pgTable("media_files", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  fileName: varchar("file_name").notNull(),
  originalName: varchar("original_name").notNull(),
  mimeType: varchar("mime_type").notNull(),
  size: integer("size").notNull(), // in bytes
  url: varchar("url").notNull(),
  entityType: varchar("entity_type").notNull(), // restaurant, menu_item, offer, category
  entityId: uuid("entity_id"),
  uploadedBy: varchar("uploaded_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

// جدول الكوبونات
export const coupons = pgTable("coupons", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  code: varchar("code").unique().notNull(),
  nameAr: varchar("name_ar").notNull(),
  discountType: varchar("discount_type").notNull(), // percentage, fixed_amount
  discountValue: integer("discount_value").notNull(),
  minimumOrder: integer("minimum_order"),
  maximumDiscount: integer("maximum_discount"), // للخصم النسبي
  usageLimit: integer("usage_limit"),
  usedCount: integer("used_count").default(0),
  isActive: boolean("is_active").default(true),
  validFrom: timestamp("valid_from").defaultNow(),
  validUntil: timestamp("valid_until"),
  applicableRestaurants: uuid("applicable_restaurants").array(), // مطاعم محددة أو null للكل
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  orders: many(orders, { relationName: "customer_orders" }),
  deliveries: many(orders, { relationName: "driver_deliveries" }),
  restaurants: many(restaurants),
}));

export const categoriesRelations = relations(categories, ({ many }) => ({
  restaurants: many(restaurants),
}));

export const restaurantsRelations = relations(restaurants, ({ one, many }) => ({
  category: one(categories, {
    fields: [restaurants.categoryId],
    references: [categories.id],
  }),
  owner: one(users, {
    fields: [restaurants.ownerId],
    references: [users.id],
  }),
  menuItems: many(menuItems),
  orders: many(orders),
  offers: many(offers),
}));

export const menuItemsRelations = relations(menuItems, ({ one, many }) => ({
  restaurant: one(restaurants, {
    fields: [menuItems.restaurantId],
    references: [restaurants.id],
  }),
  orderItems: many(orderItems),
}));

export const ordersRelations = relations(orders, ({ one, many }) => ({
  customer: one(users, {
    fields: [orders.customerId],
    references: [users.id],
    relationName: "customer_orders",
  }),
  driver: one(users, {
    fields: [orders.driverId],
    references: [users.id],
    relationName: "driver_deliveries",
  }),
  restaurant: one(restaurants, {
    fields: [orders.restaurantId],
    references: [restaurants.id],
  }),
  items: many(orderItems),
}));

export const orderItemsRelations = relations(orderItems, ({ one }) => ({
  order: one(orders, {
    fields: [orderItems.orderId],
    references: [orders.id],
  }),
  menuItem: one(menuItems, {
    fields: [orderItems.menuItemId],
    references: [menuItems.id],
  }),
}));

export const offersRelations = relations(offers, ({ one }) => ({
  restaurant: one(restaurants, {
    fields: [offers.restaurantId],
    references: [restaurants.id],
  }),
}));

export const mediaFilesRelations = relations(mediaFiles, ({ one }) => ({
  uploader: one(users, {
    fields: [mediaFiles.uploadedBy],
    references: [users.id],
  }),
}));

export const couponsRelations = relations(coupons, ({ one }) => ({
  creator: one(users, {
    fields: [coupons.createdBy],
    references: [users.id],
  }),
}));

// Export types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type InsertCategory = typeof categories.$inferInsert;
export type Category = typeof categories.$inferSelect;
export type InsertRestaurant = typeof restaurants.$inferInsert;
export type Restaurant = typeof restaurants.$inferSelect;
export type InsertMenuItem = typeof menuItems.$inferInsert;
export type MenuItem = typeof menuItems.$inferSelect;
export type InsertOrder = typeof orders.$inferInsert;
export type Order = typeof orders.$inferSelect;
export type InsertOrderItem = typeof orderItems.$inferInsert;
export type OrderItem = typeof orderItems.$inferSelect;
export type InsertOffer = typeof offers.$inferInsert;
export type Offer = typeof offers.$inferSelect;
export type InsertMediaFile = typeof mediaFiles.$inferInsert;
export type MediaFile = typeof mediaFiles.$inferSelect;
export type InsertCoupon = typeof coupons.$inferInsert;
export type Coupon = typeof coupons.$inferSelect;

// Insert schemas
export const insertCategorySchema = createInsertSchema(categories).omit({
  id: true,
  createdAt: true,
});

export const insertRestaurantSchema = createInsertSchema(restaurants).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertMenuItemSchema = createInsertSchema(menuItems).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertOrderSchema = createInsertSchema(orders).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertOrderItemSchema = createInsertSchema(orderItems).omit({
  id: true,
});

export const insertOfferSchema = createInsertSchema(offers).omit({
  id: true,
  createdAt: true,
  usedCount: true,
});

export const insertMediaFileSchema = createInsertSchema(mediaFiles).omit({
  id: true,
  createdAt: true,
});

export const insertCouponSchema = createInsertSchema(coupons).omit({
  id: true,
  createdAt: true,
  usedCount: true,
});

// Insert types
export type InsertCategoryInput = z.infer<typeof insertCategorySchema>;
export type InsertRestaurantInput = z.infer<typeof insertRestaurantSchema>;
export type InsertMenuItemInput = z.infer<typeof insertMenuItemSchema>;
export type InsertOrderInput = z.infer<typeof insertOrderSchema>;
export type InsertOfferInput = z.infer<typeof insertOfferSchema>;
export type InsertMediaFileInput = z.infer<typeof insertMediaFileSchema>;
export type InsertCouponInput = z.infer<typeof insertCouponSchema>;
