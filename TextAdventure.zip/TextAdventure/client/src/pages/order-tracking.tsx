import { useParams } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import BottomNav from "@/components/layout/bottom-nav";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

const statusSteps = [
  { key: "confirmed", label: "تم تأكيد الطلب", icon: "fas fa-check" },
  { key: "preparing", label: "يتم تحضير الطلب", icon: "fas fa-utensils" },
  { key: "out_for_delivery", label: "في الطريق إليك", icon: "fas fa-motorcycle" },
  { key: "delivered", label: "تم التوصيل", icon: "fas fa-home" },
];

export default function OrderTracking() {
  const { id } = useParams();
  const { toast } = useToast();

  const { data: order, isLoading, refetch } = useQuery({
    queryKey: ["/api/orders", id],
    enabled: !!id,
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const cancelOrderMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("PATCH", `/api/orders/${id}/status`, { status: "cancelled" });
    },
    onSuccess: () => {
      toast({
        title: "تم إلغاء الطلب",
        description: "تم إلغاء طلبك بنجاح",
      });
      refetch();
    },
    onError: () => {
      toast({
        title: "خطأ في إلغاء الطلب",
        description: "لا يمكن إلغاء الطلب في هذا الوقت",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background pb-20">
        <Header title="تتبع الطلب" showBack />
        <div className="max-w-md mx-auto p-4 space-y-4">
          <Skeleton className="h-32 w-full rounded-lg" />
          <Skeleton className="h-48 w-full rounded-lg" />
          <Skeleton className="h-24 w-full rounded-lg" />
        </div>
        <BottomNav />
      </div>
    );
  }

  if (!order) {
    return (
      <div className="min-h-screen bg-background pb-20">
        <Header title="تتبع الطلب" showBack />
        <div className="max-w-md mx-auto p-4 text-center">
          <Card className="p-8">
            <i className="fas fa-exclamation-triangle text-4xl text-destructive mb-4"></i>
            <h2 className="text-xl font-semibold mb-2">لم يتم العثور على الطلب</h2>
          </Card>
        </div>
        <BottomNav />
      </div>
    );
  }

  const currentStepIndex = statusSteps.findIndex(step => step.key === order?.status);
  const canCancel = order?.status === "pending" || order?.status === "confirmed";

  return (
    <div className="min-h-screen bg-background pb-20">
      <Header title="تتبع الطلب" showBack />
      
      <main className="max-w-md mx-auto p-4">
        {/* Order Status */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h3 className="font-semibold" data-testid="text-order-number">رقم الطلب: #{order?.orderNumber}</h3>
                <p className="text-sm text-muted-foreground" data-testid="text-restaurant-name">
                  {order?.restaurant?.nameAr || "مطعم الوزيكو للعربة"}
                </p>
              </div>
              <Badge 
                variant={order?.status === "delivered" ? "default" : "secondary"}
                className={order?.status === "out_for_delivery" ? "bg-green-100 text-green-800" : ""}
                data-testid="badge-order-status"
              >
                {order?.status === "pending" && "في الانتظار"}
                {order?.status === "confirmed" && "مؤكد"}
                {order?.status === "preparing" && "قيد التحضير"}
                {order?.status === "out_for_delivery" && "في الطريق"}
                {order?.status === "delivered" && "تم التوصيل"}
                {order?.status === "cancelled" && "ملغي"}
              </Badge>
            </div>
            
            {/* Progress Steps */}
            <div className="space-y-4">
              {statusSteps.map((step, index) => {
                const isCompleted = index <= currentStepIndex;
                const isCurrent = index === currentStepIndex;
                
                return (
                  <div key={step.key} className="flex items-center space-x-reverse space-x-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      isCompleted 
                        ? (isCurrent ? "bg-primary" : "bg-green-500")
                        : "bg-muted"
                    }`}>
                      <i className={`${step.icon} text-white text-sm`}></i>
                    </div>
                    <div className="flex-1">
                      <p className={`font-medium ${isCompleted ? "text-foreground" : "text-muted-foreground"}`}>
                        {step.label}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {index === 0 && isCompleted && "تم في 2:30 م"}
                        {index === 1 && isCompleted && "تم في 2:35 م"}
                        {index === 2 && isCurrent && "منذ 10 دقائق"}
                        {index === 3 && !isCompleted && "متوقع خلال 15 دقيقة"}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Driver Info */}
        {order.status === "out_for_delivery" && (
          <Card className="mb-6">
            <CardContent className="p-4">
              <h3 className="font-semibold mb-3">معلومات السائق</h3>
              <div className="flex items-center space-x-reverse space-x-3">
                <img 
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=64&h=64"
                  alt="السائق أحمد"
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div className="flex-1">
                  <p className="font-medium" data-testid="text-driver-name">أحمد محمد الصالحي</p>
                  <div className="flex items-center space-x-reverse space-x-1">
                    <i className="fas fa-star text-yellow-400 text-sm"></i>
                    <span className="text-sm" data-testid="text-driver-rating">4.9</span>
                  </div>
                </div>
                <Button size="sm" className="p-2" data-testid="button-call-driver">
                  <i className="fas fa-phone"></i>
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Map Placeholder */}
        <Card className="mb-6">
          <CardContent className="p-8 text-center">
            <i className="fas fa-map text-4xl text-muted-foreground mb-3"></i>
            <p className="text-muted-foreground">خريطة تتبع الموقع</p>
            <p className="text-sm text-muted-foreground" data-testid="text-remaining-distance">المسافة المتبقية: 2.5 كم</p>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="space-y-3">
          {order.status === "out_for_delivery" && (
            <Button className="w-full py-3 font-medium" data-testid="button-call-driver-main">
              <i className="fas fa-phone ml-2"></i>
              اتصال بالسائق
            </Button>
          )}
          
          {canCancel && (
            <Button 
              variant="destructive" 
              className="w-full py-3 font-medium"
              onClick={() => cancelOrderMutation.mutate()}
              disabled={cancelOrderMutation.isPending}
              data-testid="button-cancel-order"
            >
              {cancelOrderMutation.isPending ? "جاري الإلغاء..." : "إلغاء الطلب"}
            </Button>
          )}
        </div>
      </main>

      <BottomNav />
    </div>
  );
}
