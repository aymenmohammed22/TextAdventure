import { useQuery } from "@tanstack/react-query";
import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Header from "@/components/layout/header";
import BottomNav from "@/components/layout/bottom-nav";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";

export default function Admin() {
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading } = useAuth();

  // Redirect to home if not authenticated or not admin
  useEffect(() => {
    if (!isLoading && (!isAuthenticated || user?.role !== 'admin')) {
      toast({
        title: "غير مخول",
        description: "أنت بحاجة لصلاحيات المدير للوصول لهذه الصفحة",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/";
      }, 1000);
      return;
    }
  }, [isAuthenticated, isLoading, user, toast]);

  const { data: orders, isLoading: ordersLoading } = useQuery({
    queryKey: ["/api/admin/orders"],
    enabled: !!user && user.role === 'admin',
  });

  const { data: restaurants } = useQuery({
    queryKey: ["/api/restaurants"],
    enabled: !!user && user.role === 'admin',
  });

  if (isLoading || !isAuthenticated || user?.role !== 'admin') {
    return (
      <div className="min-h-screen bg-background pb-20">
        <Header title="لوحة التحكم" />
        <div className="max-w-md mx-auto p-4">
          <Skeleton className="h-32 w-full rounded-lg" />
        </div>
        <BottomNav />
      </div>
    );
  }

  const todayOrders = orders?.filter((order: any) => {
    const today = new Date().toDateString();
    return new Date(order.createdAt).toDateString() === today;
  }) || [];

  const activeRestaurants = restaurants?.filter((r: any) => r.isOpen) || [];

  return (
    <div className="min-h-screen bg-background pb-20">
      <Header title="لوحة التحكم" />
      
      <main className="max-w-md mx-auto p-4">
        {/* Stats Cards */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <Card>
            <CardContent className="p-4 text-center">
              <i className="fas fa-shopping-cart text-primary text-2xl mb-2"></i>
              <p className="text-2xl font-bold" data-testid="text-today-orders">{todayOrders.length}</p>
              <p className="text-sm text-muted-foreground">طلبات اليوم</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4 text-center">
              <i className="fas fa-store text-green-600 text-2xl mb-2"></i>
              <p className="text-2xl font-bold" data-testid="text-active-restaurants">{activeRestaurants.length}</p>
              <p className="text-sm text-muted-foreground">المطاعم النشطة</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4 text-center">
              <i className="fas fa-motorcycle text-blue-600 text-2xl mb-2"></i>
              <p className="text-2xl font-bold" data-testid="text-available-drivers">12</p>
              <p className="text-sm text-muted-foreground">السائقين المتاحين</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4 text-center">
              <i className="fas fa-money-bill text-yellow-600 text-2xl mb-2"></i>
              <p className="text-2xl font-bold" data-testid="text-revenue">850K</p>
              <p className="text-sm text-muted-foreground">الإيرادات (ر.ي)</p>
            </CardContent>
          </Card>
        </div>

        {/* Recent Orders */}
        <div className="mb-6">
          <h3 className="text-lg font-semibold mb-3">الطلبات الحديثة</h3>
          {ordersLoading ? (
            Array.from({ length: 3 }).map((_, i) => (
              <Card key={i} className="mb-3">
                <CardContent className="p-4">
                  <div className="flex justify-between items-center">
                    <div className="space-y-2 flex-1">
                      <Skeleton className="h-4 w-1/2" />
                      <Skeleton className="h-3 w-3/4" />
                    </div>
                    <Skeleton className="h-6 w-16" />
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            todayOrders.slice(0, 5).map((order: any) => (
              <Card key={order.id} className="mb-3">
                <CardContent className="p-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-medium" data-testid={`text-order-${order.id}`}>#{order.orderNumber}</p>
                      <p className="text-sm text-muted-foreground">
                        {order.total.toLocaleString()} ر.ي
                      </p>
                    </div>
                    <Badge 
                      variant={order.status === "delivered" ? "default" : "secondary"}
                      data-testid={`badge-status-${order.id}`}
                    >
                      {order.status === "pending" && "في الانتظار"}
                      {order.status === "confirmed" && "مؤكد"}
                      {order.status === "preparing" && "قيد التحضير"}
                      {order.status === "out_for_delivery" && "في الطريق"}
                      {order.status === "delivered" && "تم التوصيل"}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>

        {/* Quick Actions */}
        <div className="space-y-3">
          <Button 
            variant="outline" 
            className="w-full text-right p-4 justify-between"
            data-testid="button-manage-restaurants"
          >
            <div className="flex items-center space-x-reverse space-x-3">
              <i className="fas fa-utensils text-primary"></i>
              <span className="font-medium">إدارة المطاعم</span>
            </div>
            <i className="fas fa-chevron-left text-muted-foreground"></i>
          </Button>
          
          <Button 
            variant="outline" 
            className="w-full text-right p-4 justify-between"
            data-testid="button-manage-orders"
          >
            <div className="flex items-center space-x-reverse space-x-3">
              <i className="fas fa-list text-blue-600"></i>
              <span className="font-medium">إدارة الطلبات</span>
            </div>
            <i className="fas fa-chevron-left text-muted-foreground"></i>
          </Button>
          
          <Button 
            variant="outline" 
            className="w-full text-right p-4 justify-between"
            data-testid="button-manage-offers"
          >
            <div className="flex items-center space-x-reverse space-x-3">
              <i className="fas fa-tags text-green-600"></i>
              <span className="font-medium">إدارة العروض</span>
            </div>
            <i className="fas fa-chevron-left text-muted-foreground"></i>
          </Button>
          
          <Button 
            variant="outline" 
            className="w-full text-right p-4 justify-between"
            data-testid="button-manage-drivers"
          >
            <div className="flex items-center space-x-reverse space-x-3">
              <i className="fas fa-users text-purple-600"></i>
              <span className="font-medium">إدارة السائقين</span>
            </div>
            <i className="fas fa-chevron-left text-muted-foreground"></i>
          </Button>
          
          <Button 
            variant="outline" 
            className="w-full text-right p-4 justify-between"
            data-testid="button-reports"
          >
            <div className="flex items-center space-x-reverse space-x-3">
              <i className="fas fa-chart-bar text-orange-600"></i>
              <span className="font-medium">التقارير والإحصائيات</span>
            </div>
            <i className="fas fa-chevron-left text-muted-foreground"></i>
          </Button>
        </div>
      </main>

      <BottomNav />
    </div>
  );
}
