import { useQuery, useMutation } from "@tanstack/react-query";
import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Header from "@/components/layout/header";
import BottomNav from "@/components/layout/bottom-nav";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function Driver() {
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading } = useAuth();

  // Redirect if not authenticated or not driver
  useEffect(() => {
    if (!isLoading && (!isAuthenticated || user?.role !== 'driver')) {
      toast({
        title: "غير مخول",
        description: "أنت بحاجة لصلاحيات السائق للوصول لهذه الصفحة",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/";
      }, 1000);
      return;
    }
  }, [isAuthenticated, isLoading, user, toast]);

  const { data: orders, isLoading: ordersLoading } = useQuery({
    queryKey: ["/api/driver/orders"],
    enabled: !!user && user.role === 'driver',
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ orderId, status }: { orderId: string; status: string }) => {
      return await apiRequest("PATCH", `/api/orders/${orderId}/status`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/driver/orders"] });
      toast({
        title: "تم تحديث حالة الطلب",
        description: "تم تحديث حالة الطلب بنجاح",
      });
    },
    onError: () => {
      toast({
        title: "خطأ في تحديث الحالة",
        description: "فشل في تحديث حالة الطلب",
        variant: "destructive",
      });
    },
  });

  if (isLoading || !isAuthenticated || user?.role !== 'driver') {
    return (
      <div className="min-h-screen bg-background pb-20">
        <Header title="لوحة السائق" />
        <div className="max-w-md mx-auto p-4">
          <Skeleton className="h-32 w-full rounded-lg" />
        </div>
        <BottomNav />
      </div>
    );
  }

  const availableOrders = orders?.filter((order: any) => order.status === "preparing") || [];
  const myDeliveries = orders?.filter((order: any) => order.driverId === user.id) || [];

  return (
    <div className="min-h-screen bg-background pb-20">
      <Header title="لوحة السائق" />
      
      <main className="max-w-md mx-auto p-4">
        {/* Driver Stats */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <Card>
            <CardContent className="p-4 text-center">
              <i className="fas fa-motorcycle text-primary text-2xl mb-2"></i>
              <p className="text-2xl font-bold" data-testid="text-available-orders">{availableOrders.length}</p>
              <p className="text-sm text-muted-foreground">طلبات متاحة</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4 text-center">
              <i className="fas fa-check-circle text-green-600 text-2xl mb-2"></i>
              <p className="text-2xl font-bold" data-testid="text-completed-today">8</p>
              <p className="text-sm text-muted-foreground">مكتملة اليوم</p>
            </CardContent>
          </Card>
        </div>

        {/* Available Orders */}
        <div className="mb-6">
          <h3 className="text-lg font-semibold mb-3">الطلبات المتاحة</h3>
          {ordersLoading ? (
            Array.from({ length: 2 }).map((_, i) => (
              <Card key={i} className="mb-3">
                <CardContent className="p-4">
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-1/2" />
                    <Skeleton className="h-3 w-3/4" />
                    <Skeleton className="h-8 w-full" />
                  </div>
                </CardContent>
              </Card>
            ))
          ) : availableOrders.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <i className="fas fa-clock text-4xl text-muted-foreground mb-4"></i>
                <p className="text-muted-foreground">لا توجد طلبات متاحة حالياً</p>
              </CardContent>
            </Card>
          ) : (
            availableOrders.map((order: any) => (
              <Card key={order.id} className="mb-3">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <p className="font-semibold" data-testid={`text-order-number-${order.id}`}>#{order.orderNumber}</p>
                      <p className="text-sm text-muted-foreground">
                        {order.total.toLocaleString()} ر.ي
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {order.deliveryAddress}
                      </p>
                    </div>
                    <Badge variant="secondary" data-testid={`badge-order-status-${order.id}`}>
                      جاهز للتوصيل
                    </Badge>
                  </div>
                  
                  <Button
                    className="w-full"
                    onClick={() => updateStatusMutation.mutate({ orderId: order.id, status: "out_for_delivery" })}
                    disabled={updateStatusMutation.isPending}
                    data-testid={`button-accept-order-${order.id}`}
                  >
                    قبول الطلب
                  </Button>
                </CardContent>
              </Card>
            ))
          )}
        </div>

        {/* My Deliveries */}
        <div className="mb-6">
          <h3 className="text-lg font-semibold mb-3">طلباتي الحالية</h3>
          {myDeliveries.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <i className="fas fa-clipboard-list text-4xl text-muted-foreground mb-4"></i>
                <p className="text-muted-foreground">لا توجد طلبات قيد التوصيل</p>
              </CardContent>
            </Card>
          ) : (
            myDeliveries.map((order: any) => (
              <Card key={order.id} className="mb-3">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <p className="font-semibold" data-testid={`text-my-order-${order.id}`}>#{order.orderNumber}</p>
                      <p className="text-sm text-muted-foreground">
                        {order.total.toLocaleString()} ر.ي
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {order.deliveryAddress}
                      </p>
                    </div>
                    <Badge className="bg-green-100 text-green-800">
                      في الطريق
                    </Badge>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      data-testid={`button-call-customer-${order.id}`}
                    >
                      <i className="fas fa-phone ml-1"></i>
                      اتصال
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => updateStatusMutation.mutate({ orderId: order.id, status: "delivered" })}
                      disabled={updateStatusMutation.isPending}
                      data-testid={`button-mark-delivered-${order.id}`}
                    >
                      تم التوصيل
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>

        {/* Driver Tools */}
        <div className="space-y-3">
          <Button 
            variant="outline" 
            className="w-full text-right p-4 justify-between"
            data-testid="button-my-earnings"
          >
            <div className="flex items-center space-x-reverse space-x-3">
              <i className="fas fa-money-bill text-green-600"></i>
              <span className="font-medium">أرباحي اليوم</span>
            </div>
            <span className="font-bold text-green-600">12,500 ر.ي</span>
          </Button>
          
          <Button 
            variant="outline" 
            className="w-full text-right p-4 justify-between"
            data-testid="button-delivery-history"
          >
            <div className="flex items-center space-x-reverse space-x-3">
              <i className="fas fa-history text-blue-600"></i>
              <span className="font-medium">سجل التوصيلات</span>
            </div>
            <i className="fas fa-chevron-left text-muted-foreground"></i>
          </Button>
        </div>
      </main>

      <BottomNav />
    </div>
  );
}
