import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import Header from "@/components/layout/header";
import BottomNav from "@/components/layout/bottom-nav";
import MenuItem from "@/components/menu-item";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";

export default function Restaurant() {
  const { id } = useParams();
  const [selectedCategory, setSelectedCategory] = useState("العروض");

  const { data: restaurant, isLoading: restaurantLoading } = useQuery({
    queryKey: ["/api/restaurants", id],
    enabled: !!id,
  });

  const { data: menuItems, isLoading: menuLoading } = useQuery({
    queryKey: ["/api/restaurants", id, "menu"],
    enabled: !!id,
  });

  const categories = ["العروض", "وجبات رمضان", "المقبلات", "المشروبات"];
  
  const filteredItems = Array.isArray(menuItems) ? menuItems.filter((item: any) => 
    selectedCategory === "العروض" 
      ? item.isSpecialOffer 
      : item.category === selectedCategory
  ) : [];

  if (restaurantLoading || !restaurant) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="max-w-md mx-auto">
          <Skeleton className="w-full h-48" />
          <div className="p-4 space-y-4">
            <Skeleton className="h-8 w-3/4" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-20 w-full" />
          </div>
        </div>
        <BottomNav />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      <Header showBack />
      
      <main className="max-w-md mx-auto">
        <div className="relative">
          <img 
            src={restaurant?.coverImage || "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&h=300"}
            alt={restaurant?.nameAr || "Restaurant"}
            className="w-full h-48 object-cover"
          />
        </div>

        <div className="p-4">
          {/* Restaurant Info */}
          <div className="mb-6">
            <h1 className="text-2xl font-bold mb-2" data-testid="text-restaurant-name">{restaurant?.nameAr}</h1>
            <div className="flex items-center space-x-reverse space-x-4 text-sm text-muted-foreground mb-3">
              <div className="flex items-center space-x-reverse space-x-1">
                <i className="fas fa-star text-yellow-400"></i>
                <span data-testid="text-rating">{restaurant?.rating}</span>
                <span data-testid="text-review-count">({restaurant?.reviewCount} تقييم)</span>
              </div>
              <div className="flex items-center space-x-reverse space-x-1">
                <i className="fas fa-clock text-primary"></i>
                <span data-testid="text-delivery-time">{restaurant?.deliveryTime}</span>
              </div>
            </div>
            <Card className="bg-secondary p-3">
              <div className="flex justify-between items-center">
                <div className="flex items-center space-x-reverse space-x-2">
                  <i className="fas fa-motorcycle text-primary"></i>
                  <span className="text-sm" data-testid="text-delivery-fee">رسوم التوصيل: {restaurant?.deliveryFee} ر.ي</span>
                </div>
                <span className="text-sm text-muted-foreground" data-testid="text-minimum-order">
                  الحد الأدنى: {restaurant?.minimumOrder} ر.ي
                </span>
              </div>
            </Card>
          </div>

          {/* Menu Categories */}
          <div className="mb-6">
            <div className="flex space-x-reverse space-x-2 overflow-x-auto pb-2">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "secondary"}
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                  className="flex-shrink-0"
                  data-testid={`button-menu-category-${category}`}
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>

          {/* Menu Items */}
          <div className="space-y-4">
            {menuLoading ? (
              Array.from({ length: 3 }).map((_, i) => (
                <Card key={i} className="p-4">
                  <div className="flex justify-between items-center">
                    <div className="flex-1 space-y-2">
                      <Skeleton className="h-6 w-3/4" />
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-6 w-1/3" />
                    </div>
                    <Skeleton className="w-20 h-16 rounded-lg mr-4" />
                  </div>
                </Card>
              ))
            ) : filteredItems.length === 0 ? (
              <Card className="p-8 text-center">
                <i className="fas fa-utensils text-4xl text-muted-foreground mb-4"></i>
                <p className="text-muted-foreground">لا توجد عناصر في هذا القسم</p>
              </Card>
            ) : (
              filteredItems.map((item: any) => (
                <MenuItem 
                  key={item.id} 
                  item={item} 
                  restaurant={restaurant}
                />
              ))
            )}
          </div>
        </div>
      </main>

      <BottomNav />
    </div>
  );
}
