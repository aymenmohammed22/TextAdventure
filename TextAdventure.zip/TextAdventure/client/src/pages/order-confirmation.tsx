import { useParams, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export default function OrderConfirmation() {
  const { id } = useParams();

  const { data: order, isLoading } = useQuery({
    queryKey: ["/api/orders", id],
    enabled: !!id,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header title="تأكيد الطلب" />
        <div className="max-w-md mx-auto p-4">
          <div className="text-center space-y-4">
            <Skeleton className="w-24 h-24 rounded-full mx-auto" />
            <Skeleton className="h-8 w-3/4 mx-auto" />
            <Skeleton className="h-4 w-1/2 mx-auto" />
          </div>
        </div>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="min-h-screen bg-background">
        <Header title="تأكيد الطلب" />
        <div className="max-w-md mx-auto p-4 text-center">
          <Card className="p-8">
            <i className="fas fa-exclamation-triangle text-4xl text-destructive mb-4"></i>
            <h2 className="text-xl font-semibold mb-2">لم يتم العثور على الطلب</h2>
            <Link href="/">
              <Button>العودة للرئيسية</Button>
            </Link>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header title="تأكيد الطلب" />
      
      <main className="max-w-md mx-auto p-4 text-center">
        <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <i className="fas fa-check text-green-600 text-3xl"></i>
        </div>
        
        <h1 className="text-2xl font-bold mb-2">تم تأكيد طلبك!</h1>
        <p className="text-muted-foreground mb-6" data-testid="text-order-number">
          رقم الطلب: #{order?.orderNumber}
        </p>
        
        <Card className="mb-6 text-right">
          <CardContent className="p-4">
            <h3 className="font-semibold mb-3">تفاصيل الطلب</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>المطعم</span>
                <span data-testid="text-restaurant">{order?.restaurant?.nameAr || "مطعم الوزيكو للعربة"}</span>
              </div>
              <div className="flex justify-between">
                <span>الوقت المتوقع</span>
                <span data-testid="text-estimated-time">40-60 دقيقة</span>
              </div>
              <div className="flex justify-between">
                <span>المجموع</span>
                <span className="font-bold text-primary" data-testid="text-order-total">
                  {order?.total?.toLocaleString()} ر.ي
                </span>
              </div>
              <div className="flex justify-between">
                <span>طريقة الدفع</span>
                <span data-testid="text-payment-method">
                  {order?.paymentMethod === 'cash' && 'نقداً عند الاستلام'}
                  {order?.paymentMethod === 'electronic' && 'الدفع الإلكتروني'}
                  {order?.paymentMethod === 'wallet' && 'الدفع من الرصيد'}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-3">
          <Link href={`/order-tracking/${order?.id}`}>
            <Button className="w-full py-3 font-medium" data-testid="button-track-order">
              تتبع الطلب
            </Button>
          </Link>
          <Link href="/">
            <Button variant="secondary" className="w-full py-3 font-medium" data-testid="button-back-home">
              العودة للرئيسية
            </Button>
          </Link>
        </div>
      </main>
    </div>
  );
}
