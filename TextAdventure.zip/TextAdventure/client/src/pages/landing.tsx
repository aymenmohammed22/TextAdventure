import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-primary/10 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardContent className="pt-6 text-center">
          <div className="w-20 h-20 bg-primary rounded-2xl flex items-center justify-center mb-6 mx-auto">
            <i className="fas fa-motorcycle text-primary-foreground text-3xl"></i>
          </div>
          
          <h1 className="text-3xl font-bold text-primary mb-2">السريع ون</h1>
          <p className="text-lg text-muted-foreground mb-6">تطبيق التوصيل السريع</p>
          
          <div className="space-y-4 mb-8 text-right">
            <div className="flex items-center space-x-reverse space-x-3">
              <i className="fas fa-clock text-primary"></i>
              <span className="text-sm">توصيل سريع في أقل من ساعة</span>
            </div>
            <div className="flex items-center space-x-reverse space-x-3">
              <i className="fas fa-utensils text-primary"></i>
              <span className="text-sm">أفضل المطاعم في صنعاء</span>
            </div>
            <div className="flex items-center space-x-reverse space-x-3">
              <i className="fas fa-mobile-alt text-primary"></i>
              <span className="text-sm">دفع آمن ومتعدد الطرق</span>
            </div>
            <div className="flex items-center space-x-reverse space-x-3">
              <i className="fas fa-map-marker-alt text-primary"></i>
              <span className="text-sm">تتبع مباشر للطلبات</span>
            </div>
          </div>
          
          <Button 
            onClick={handleLogin}
            className="w-full py-6 text-lg font-bold"
            data-testid="button-login"
          >
            <i className="fas fa-sign-in-alt ml-2"></i>
            دخول / تسجيل جديد
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
