import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import Header from "@/components/layout/header";
import BottomNav from "@/components/layout/bottom-nav";
import RestaurantCard from "@/components/restaurant-card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [searchQuery, setSearchQuery] = useState("");

  const { data: categories, isLoading: categoriesLoading } = useQuery({
    queryKey: ["/api/categories"],
  });

  const { data: restaurants, isLoading: restaurantsLoading } = useQuery({
    queryKey: ["/api/restaurants", selectedCategory, searchQuery],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (selectedCategory) params.append("categoryId", selectedCategory);
      if (searchQuery) params.append("search", searchQuery);
      
      const response = await fetch(`/api/restaurants?${params}`);
      return response.json();
    },
  });

  const { data: offers } = useQuery({
    queryKey: ["/api/offers"],
  });

  return (
    <div className="min-h-screen bg-background pb-20">
      <Header />
      
      <main className="max-w-md mx-auto">
        {/* Location & Search */}
        <div className="p-4 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-reverse space-x-2">
              <i className="fas fa-map-marker-alt text-primary"></i>
              <div>
                <p className="text-sm font-medium">التوصيل إلى</p>
                <p className="text-xs text-muted-foreground" data-testid="text-delivery-location">صنعاء - شارع الزبيري</p>
              </div>
            </div>
            <Button variant="ghost" size="sm" className="text-primary" data-testid="button-change-location">
              تغيير
            </Button>
          </div>
          
          <div className="relative">
            <Input
              type="text"
              placeholder="ابحث عن المطاعم والوجبات..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pr-10"
              data-testid="input-search"
            />
            <i className="fas fa-search absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground"></i>
          </div>
        </div>

        {/* Offers Banner */}
        {offers && Array.isArray(offers) && offers.length > 0 && (
          <div className="px-4 mb-4">
            <div className="hero-banner rounded-lg p-4 text-primary-foreground relative overflow-hidden">
              <div className="relative z-10">
                <h2 className="text-lg font-bold mb-1">عروض خاصة</h2>
                <p className="text-sm opacity-90">خصم حتى 30% على الطلبات الأولى</p>
                <Button 
                  variant="secondary" 
                  className="mt-2"
                  data-testid="button-order-now"
                >
                  اطلب الآن
                </Button>
              </div>
              <div className="absolute left-4 top-4 opacity-20">
                <i className="fas fa-utensils text-4xl"></i>
              </div>
            </div>
          </div>
        )}

        {/* Categories */}
        <div className="px-4 mb-6">
          <h3 className="text-lg font-semibold mb-3">التصنيفات</h3>
          <div className="flex space-x-reverse space-x-3 overflow-x-auto pb-2">
            {categoriesLoading ? (
              Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="flex-shrink-0 text-center">
                  <Skeleton className="w-16 h-16 rounded-lg mb-2" />
                  <Skeleton className="h-4 w-12" />
                </div>
              ))
            ) : (
              Array.isArray(categories) && categories.map((category: any) => (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(selectedCategory === category.id ? "" : category.id)}
                  className={`flex-shrink-0 text-center ${
                    selectedCategory === category.id 
                      ? 'text-primary' 
                      : 'text-muted-foreground'
                  }`}
                  data-testid={`button-category-${category.id}`}
                >
                  <div className={`w-16 h-16 rounded-lg flex items-center justify-center mb-2 ${
                    selectedCategory === category.id 
                      ? 'bg-primary/10' 
                      : 'bg-accent'
                  }`}>
                    <i className={`${category.icon} text-xl`}></i>
                  </div>
                  <p className="text-xs font-medium">{category.nameAr}</p>
                </button>
              ))
            )}
          </div>
        </div>

        {/* Restaurants List */}
        <div className="px-4 space-y-4">
          <h3 className="text-lg font-semibold">المطاعم القريبة</h3>
          
          {restaurantsLoading ? (
            Array.from({ length: 3 }).map((_, i) => (
              <Card key={i} className="overflow-hidden">
                <Skeleton className="w-full h-32" />
                <div className="p-4 space-y-2">
                  <Skeleton className="h-6 w-3/4" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-1/2" />
                </div>
              </Card>
            ))
          ) : restaurants?.length === 0 ? (
            <Card className="p-8 text-center">
              <i className="fas fa-search text-4xl text-muted-foreground mb-4"></i>
              <p className="text-muted-foreground">لا توجد مطاعم متاحة</p>
            </Card>
          ) : (
            restaurants?.map((restaurant: any) => (
              <RestaurantCard key={restaurant.id} restaurant={restaurant} />
            ))
          )}
        </div>
      </main>

      <BottomNav />
    </div>
  );
}
