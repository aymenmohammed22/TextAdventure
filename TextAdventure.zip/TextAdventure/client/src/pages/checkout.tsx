import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import Header from "@/components/layout/header";
import { useCartStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function Checkout() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { items, restaurantId, restaurantName, deliveryFee, getSubtotal, getTotal, clearCart } = useCartStore();
  const [deliveryTime, setDeliveryTime] = useState("asap");
  const [paymentMethod, setPaymentMethod] = useState("cash");

  const createOrderMutation = useMutation({
    mutationFn: async (orderData: any) => {
      return await apiRequest("POST", "/api/orders", orderData);
    },
    onSuccess: async (response) => {
      const order = await response.json();
      clearCart();
      setLocation(`/order-confirmation/${order.id}`);
    },
    onError: (error) => {
      toast({
        title: "خطأ في إنشاء الطلب",
        description: "حدث خطأ أثناء إنشاء الطلب. حاول مرة أخرى.",
        variant: "destructive",
      });
    },
  });

  const handlePlaceOrder = () => {
    if (items.length === 0) return;

    const orderData = {
      order: {
        restaurantId,
        subtotal: getSubtotal(),
        deliveryFee,
        total: getTotal(),
        paymentMethod,
        deliveryAddress: "صنعاء - شارع الزبيري - منزل رقم 25",
        deliveryLatitude: "15.3694",
        deliveryLongitude: "44.191",
        estimatedDeliveryTime: deliveryTime === "asap" 
          ? new Date(Date.now() + 60 * 60 * 1000) // 1 hour from now
          : new Date(Date.now() + 2 * 60 * 60 * 1000), // 2 hours from now
      },
      items: items.map(item => ({
        menuItemId: item.menuItemId,
        quantity: item.quantity,
        price: item.price,
        notes: item.notes,
      })),
    };

    createOrderMutation.mutate(orderData);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header title="إتمام الطلب" showBack />
      
      <main className="max-w-md mx-auto p-4">
        {/* Delivery Time */}
        <Card className="mb-4">
          <CardContent className="p-4">
            <h3 className="font-semibold mb-3">وقت التوصيل</h3>
            <RadioGroup value={deliveryTime} onValueChange={setDeliveryTime}>
              <div className="flex items-center space-x-reverse space-x-3">
                <RadioGroupItem value="asap" id="asap" />
                <Label htmlFor="asap" className="cursor-pointer flex-1">
                  <div>
                    <p className="font-medium">في أسرع وقت</p>
                    <p className="text-sm text-muted-foreground">40-60 دقيقة</p>
                  </div>
                </Label>
              </div>
              <div className="flex items-center space-x-reverse space-x-3">
                <RadioGroupItem value="scheduled" id="scheduled" />
                <Label htmlFor="scheduled" className="cursor-pointer flex-1">
                  <div>
                    <p className="font-medium">حدد وقت محدد</p>
                    <p className="text-sm text-muted-foreground">اختر الوقت المناسب لك</p>
                  </div>
                </Label>
              </div>
            </RadioGroup>
          </CardContent>
        </Card>

        {/* Payment Methods */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <h3 className="font-semibold mb-3">طريقة الدفع</h3>
            <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod}>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-reverse space-x-3">
                  <RadioGroupItem value="cash" id="cash" />
                  <Label htmlFor="cash" className="cursor-pointer flex items-center space-x-reverse space-x-2">
                    <i className="fas fa-money-bills text-green-600"></i>
                    <span>الدفع عند الاستلام</span>
                  </Label>
                </div>
                <span className="text-sm text-muted-foreground">نقداً</span>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-reverse space-x-3">
                  <RadioGroupItem value="electronic" id="electronic" />
                  <Label htmlFor="electronic" className="cursor-pointer flex items-center space-x-reverse space-x-2">
                    <i className="fas fa-mobile-alt text-primary"></i>
                    <span>الدفع الإلكتروني</span>
                  </Label>
                </div>
                <span className="text-sm text-muted-foreground">محفظة أو بطاقة</span>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-reverse space-x-3">
                  <RadioGroupItem value="wallet" id="wallet" />
                  <Label htmlFor="wallet" className="cursor-pointer flex items-center space-x-reverse space-x-2">
                    <i className="fas fa-wallet text-blue-600"></i>
                    <span>الدفع من الرصيد</span>
                  </Label>
                </div>
                <span className="text-sm text-green-600">الرصيد: 15,000 ر.ي</span>
              </div>
            </RadioGroup>
          </CardContent>
        </Card>

        {/* Final Order Summary */}
        <Card className="border-primary/20 bg-primary/5 mb-6">
          <CardContent className="p-4">
            <h3 className="font-semibold mb-3">تأكيد الطلب</h3>
            <div className="space-y-2 text-sm">
              {items.map((item) => (
                <div key={item.id} className="flex justify-between">
                  <span>{item.nameAr} × {item.quantity}</span>
                  <span>{(item.price * item.quantity).toLocaleString()} ر.ي</span>
                </div>
              ))}
              <div className="flex justify-between">
                <span>رسوم التوصيل</span>
                <span>{deliveryFee.toLocaleString()} ر.ي</span>
              </div>
              <Separator />
              <div className="flex justify-between font-bold text-lg text-primary">
                <span>المجموع النهائي</span>
                <span data-testid="text-final-total">{getTotal().toLocaleString()} ر.ي</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Place Order Button */}
        <Button 
          className="w-full py-4 text-lg font-bold"
          onClick={handlePlaceOrder}
          disabled={createOrderMutation.isPending}
          data-testid="button-place-order"
        >
          {createOrderMutation.isPending ? (
            <>
              <i className="fas fa-spinner fa-spin ml-2"></i>
              جاري إنشاء الطلب...
            </>
          ) : (
            `تأكيد الطلب`
          )}
        </Button>
      </main>
    </div>
  );
}
