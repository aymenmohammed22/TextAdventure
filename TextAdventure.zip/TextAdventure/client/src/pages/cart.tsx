import { Link } from "wouter";
import Header from "@/components/layout/header";
import BottomNav from "@/components/layout/bottom-nav";
import CartItem from "@/components/cart-item";
import { useCartStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";

export default function Cart() {
  const { items, restaurantName, deliveryFee, getSubtotal, getTotal, clearCart } = useCartStore();
  const [notes, setNotes] = useState("");

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-background pb-20">
        <Header title="سلة التسوق" showBack />
        
        <main className="max-w-md mx-auto p-4">
          <Card className="p-8 text-center">
            <i className="fas fa-shopping-cart text-4xl text-muted-foreground mb-4"></i>
            <h2 className="text-xl font-semibold mb-2">سلة التسوق فارغة</h2>
            <p className="text-muted-foreground mb-4">أضف بعض الأطعام اللذيذة لتبدأ</p>
            <Link href="/">
              <Button data-testid="button-browse-restaurants">
                تصفح المطاعم
              </Button>
            </Link>
          </Card>
        </main>

        <BottomNav />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      <Header title="سلة التسوق" showBack />
      
      <main className="max-w-md mx-auto p-4">
        {/* Cart Items */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="flex justify-between items-start mb-3">
              <h3 className="font-semibold" data-testid="text-restaurant-name">{restaurantName}</h3>
              <span className="text-xs text-muted-foreground" data-testid="text-delivery-fee">
                رسوم توصيل: {deliveryFee} ر.ي
              </span>
            </div>
            
            <div className="space-y-3">
              {items.map((item) => (
                <CartItem key={item.id} item={item} />
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Order Summary */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <h3 className="font-semibold mb-3">ملخص الطلب</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>المجموع الفرعي</span>
                <span data-testid="text-subtotal">{getSubtotal().toLocaleString()} ر.ي</span>
              </div>
              <div className="flex justify-between">
                <span>رسوم التوصيل</span>
                <span data-testid="text-delivery-fee-summary">{deliveryFee.toLocaleString()} ر.ي</span>
              </div>
              <Separator />
              <div className="flex justify-between font-bold text-lg">
                <span>المجموع الكلي</span>
                <span className="text-primary" data-testid="text-total">{getTotal().toLocaleString()} ر.ي</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Delivery Address */}
        <Card className="mb-4">
          <CardContent className="p-4">
            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-reverse space-x-3">
                <i className="fas fa-map-marker-alt text-primary"></i>
                <div>
                  <p className="font-medium">عنوان التوصيل</p>
                  <p className="text-sm text-muted-foreground" data-testid="text-delivery-address">
                    صنعاء - شارع الزبيري - منزل رقم 25
                  </p>
                </div>
              </div>
              <Button variant="ghost" size="sm" className="text-primary" data-testid="button-change-address">
                تغيير
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Order Notes */}
        <div className="mb-6">
          <label className="block text-sm font-medium mb-2">ملاحظات الطلب (اختياري)</label>
          <Textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="أضف أي ملاحظات خاصة للطلب..."
            rows={3}
            data-testid="textarea-order-notes"
          />
        </div>

        {/* Action Buttons */}
        <div className="space-y-3">
          <Link href="/checkout">
            <Button className="w-full py-4 text-lg font-bold" data-testid="button-proceed-checkout">
              متابعة الدفع - {getTotal().toLocaleString()} ر.ي
            </Button>
          </Link>
          
          <Button 
            variant="outline" 
            className="w-full" 
            onClick={clearCart}
            data-testid="button-clear-cart"
          >
            إفراغ السلة
          </Button>
        </div>
      </main>

      <BottomNav />
    </div>
  );
}
