import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface CartItem {
  id: string;
  menuItemId: string;
  name: string;
  nameAr: string;
  price: number;
  quantity: number;
  image?: string;
  notes?: string;
}

interface CartStore {
  items: CartItem[];
  restaurantId: string | null;
  restaurantName: string | null;
  deliveryFee: number;
  addItem: (item: Omit<CartItem, 'quantity'> & { quantity?: number }, restaurantId: string, restaurantName: string, deliveryFee: number) => void;
  removeItem: (id: string) => void;
  updateQuantity: (id: string, quantity: number) => void;
  clearCart: () => void;
  getTotal: () => number;
  getSubtotal: () => number;
}

export const useCartStore = create<CartStore>()(
  persist(
    (set, get) => ({
      items: [],
      restaurantId: null,
      restaurantName: null,
      deliveryFee: 0,
      
      addItem: (item, restaurantId, restaurantName, deliveryFee) => {
        const state = get();
        
        // If adding from different restaurant, clear cart
        if (state.restaurantId && state.restaurantId !== restaurantId) {
          set({
            items: [{ ...item, quantity: item.quantity || 1 }],
            restaurantId,
            restaurantName,
            deliveryFee,
          });
          return;
        }
        
        const existingItem = state.items.find(i => i.menuItemId === item.menuItemId);
        
        if (existingItem) {
          set({
            items: state.items.map(i =>
              i.menuItemId === item.menuItemId
                ? { ...i, quantity: i.quantity + (item.quantity || 1) }
                : i
            ),
          });
        } else {
          set({
            items: [...state.items, { ...item, quantity: item.quantity || 1 }],
            restaurantId,
            restaurantName,
            deliveryFee,
          });
        }
      },
      
      removeItem: (id) => {
        const state = get();
        const newItems = state.items.filter(item => item.id !== id);
        
        if (newItems.length === 0) {
          set({
            items: [],
            restaurantId: null,
            restaurantName: null,
            deliveryFee: 0,
          });
        } else {
          set({ items: newItems });
        }
      },
      
      updateQuantity: (id, quantity) => {
        if (quantity <= 0) {
          get().removeItem(id);
          return;
        }
        
        set({
          items: get().items.map(item =>
            item.id === id ? { ...item, quantity } : item
          ),
        });
      },
      
      clearCart: () => {
        set({
          items: [],
          restaurantId: null,
          restaurantName: null,
          deliveryFee: 0,
        });
      },
      
      getSubtotal: () => {
        return get().items.reduce((total, item) => total + (item.price * item.quantity), 0);
      },
      
      getTotal: () => {
        return get().getSubtotal() + get().deliveryFee;
      },
    }),
    {
      name: 'cart-storage',
    }
  )
);
