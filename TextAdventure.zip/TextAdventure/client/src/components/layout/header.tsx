import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useCartStore } from "@/lib/store";
import { useAuth } from "@/hooks/useAuth";

interface HeaderProps {
  title?: string;
  showBack?: boolean;
}

export default function Header({ title, showBack }: HeaderProps) {
  const [, setLocation] = useLocation();
  const { items } = useCartStore();
  const { user } = useAuth();
  
  const cartItemCount = items.reduce((total, item) => total + item.quantity, 0);

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  return (
    <header className="bg-card border-b border-border sticky top-0 z-50">
      <div className="max-w-md mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-reverse space-x-3">
            {showBack ? (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => setLocation("/")}
                data-testid="button-back"
              >
                <i className="fas fa-arrow-right text-xl"></i>
              </Button>
            ) : (
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <i className="fas fa-motorcycle text-primary-foreground text-lg"></i>
              </div>
            )}
            <div>
              {title ? (
                <h1 className="text-lg font-bold" data-testid="text-page-title">{title}</h1>
              ) : (
                <>
                  <h1 className="text-lg font-bold text-primary">السريع ون</h1>
                  <p className="text-xs text-muted-foreground">التوصيل السريع</p>
                </>
              )}
            </div>
          </div>
          
          <div className="flex items-center space-x-reverse space-x-2">
            <Button variant="ghost" size="sm" onClick={handleLogout} data-testid="button-user-menu">
              <i className="fas fa-user"></i>
            </Button>
            
            <Link href="/cart">
              <Button variant="ghost" size="sm" className="relative" data-testid="button-cart">
                <i className="fas fa-shopping-cart"></i>
                {cartItemCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-primary text-primary-foreground text-xs rounded-full w-5 h-5 flex items-center justify-center" data-testid="text-cart-count">
                    {cartItemCount}
                  </span>
                )}
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
}
