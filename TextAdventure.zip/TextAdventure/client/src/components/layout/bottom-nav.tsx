import { useLocation, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";

export default function BottomNav() {
  const [location] = useLocation();
  const { user } = useAuth();

  const navItems = [
    { path: "/", icon: "fas fa-home", label: "الرئيسية", testId: "nav-home" },
    { path: "/cart", icon: "fas fa-shopping-cart", label: "السلة", testId: "nav-cart" },
    { path: "/order-tracking", icon: "fas fa-map-marker-alt", label: "التتبع", testId: "nav-tracking" },
  ];

  // Add admin/driver specific nav items based on user role
  if ((user as any)?.role === 'admin') {
    navItems.push({ path: "/admin", icon: "fas fa-cog", label: "إدارة", testId: "nav-admin" });
  } else if ((user as any)?.role === 'driver') {
    navItems.push({ path: "/driver", icon: "fas fa-motorcycle", label: "التوصيل", testId: "nav-driver" });
  }

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border max-w-md mx-auto">
      <div className="flex justify-around py-2">
        {navItems.map((item) => {
          const isActive = location === item.path || 
            (item.path === "/order-tracking" && location.startsWith("/order-tracking"));
          
          return (
            <Link key={item.path} href={item.path}>
              <Button
                variant="ghost"
                size="sm"
                className={`flex flex-col items-center p-2 h-auto ${
                  isActive ? "text-primary" : "text-muted-foreground"
                }`}
                data-testid={item.testId}
              >
                <i className={`${item.icon} text-lg mb-1`}></i>
                <span className="text-xs">{item.label}</span>
              </Button>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
