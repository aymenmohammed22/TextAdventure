import { Link } from "wouter";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface RestaurantCardProps {
  restaurant: any;
}

export default function RestaurantCard({ restaurant }: RestaurantCardProps) {
  return (
    <Link href={`/restaurant/${restaurant.id}`}>
      <Card className="overflow-hidden shadow-sm hover:shadow-md transition-shadow cursor-pointer" data-testid={`card-restaurant-${restaurant.id}`}>
        <img 
          src={restaurant.image || "https://images.unsplash.com/photo-1544148103-0773bf10d330?auto=format&fit=crop&w=800&h=200"}
          alt={restaurant.nameAr}
          className="w-full h-32 object-cover"
        />
        <div className="p-4">
          <div className="flex justify-between items-start mb-2">
            <h4 className="font-semibold text-lg" data-testid={`text-restaurant-name-${restaurant.id}`}>
              {restaurant.nameAr}
            </h4>
            <Badge 
              variant={restaurant.isOpen ? "default" : "secondary"}
              className={restaurant.isOpen ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}
              data-testid={`badge-restaurant-status-${restaurant.id}`}
            >
              {restaurant.isOpen ? "مفتوح" : "مغلق"}
            </Badge>
          </div>
          
          <div className="flex items-center space-x-reverse space-x-4 text-sm text-muted-foreground mb-2">
            <div className="flex items-center space-x-reverse space-x-1">
              <i className="fas fa-star text-yellow-400"></i>
              <span data-testid={`text-rating-${restaurant.id}`}>{restaurant.rating}</span>
              <span data-testid={`text-review-count-${restaurant.id}`}>({restaurant.reviewCount})</span>
            </div>
            <div className="flex items-center space-x-reverse space-x-1">
              <i className="fas fa-clock text-primary"></i>
              <span data-testid={`text-delivery-time-${restaurant.id}`}>{restaurant.deliveryTime}</span>
            </div>
          </div>
          
          <div className="flex justify-between items-center">
            <p className="text-sm text-muted-foreground" data-testid={`text-minimum-order-${restaurant.id}`}>
              الحد الأدنى: {restaurant.minimumOrder?.toLocaleString()} ر.ي
            </p>
            <p className="text-sm text-primary font-medium" data-testid={`text-delivery-fee-${restaurant.id}`}>
              رسوم توصيل: {restaurant.deliveryFee?.toLocaleString()} ر.ي
            </p>
          </div>
        </div>
      </Card>
    </Link>
  );
}
