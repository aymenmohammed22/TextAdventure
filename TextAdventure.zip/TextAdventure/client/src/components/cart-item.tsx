import { Button } from "@/components/ui/button";
import { useCartStore } from "@/lib/store";

interface CartItemProps {
  item: any;
}

export default function CartItem({ item }: CartItemProps) {
  const { updateQuantity, removeItem } = useCartStore();

  const handleQuantityChange = (newQuantity: number) => {
    if (newQuantity <= 0) {
      removeItem(item.id);
    } else {
      updateQuantity(item.id, newQuantity);
    }
  };

  return (
    <div className="flex justify-between items-center py-3 border-b border-border last:border-b-0">
      <div className="flex-1">
        <h4 className="font-medium" data-testid={`text-cart-item-name-${item.id}`}>
          {item.nameAr}
        </h4>
        {item.notes && (
          <p className="text-sm text-muted-foreground" data-testid={`text-cart-item-notes-${item.id}`}>
            {item.notes}
          </p>
        )}
        <p className="text-sm text-muted-foreground" data-testid={`text-cart-item-unit-price-${item.id}`}>
          {item.price.toLocaleString()} ر.ي للوحدة
        </p>
      </div>
      
      <div className="flex items-center space-x-reverse space-x-3">
        <div className="flex items-center space-x-reverse space-x-2">
          <Button
            variant="outline"
            size="sm"
            className="w-8 h-8 p-0"
            onClick={() => handleQuantityChange(item.quantity - 1)}
            data-testid={`button-decrease-${item.id}`}
          >
            <i className="fas fa-minus text-xs"></i>
          </Button>
          
          <span className="font-medium min-w-[2rem] text-center" data-testid={`text-quantity-${item.id}`}>
            {item.quantity}
          </span>
          
          <Button
            size="sm"
            className="w-8 h-8 p-0"
            onClick={() => handleQuantityChange(item.quantity + 1)}
            data-testid={`button-increase-${item.id}`}
          >
            <i className="fas fa-plus text-xs"></i>
          </Button>
        </div>
        
        <span className="font-bold text-primary min-w-[80px] text-left" data-testid={`text-total-price-${item.id}`}>
          {(item.price * item.quantity).toLocaleString()} ر.ي
        </span>
      </div>
    </div>
  );
}
