import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useCartStore } from "@/lib/store";
import { useToast } from "@/hooks/use-toast";

interface MenuItemProps {
  item: any;
  restaurant: any;
}

export default function MenuItem({ item, restaurant }: MenuItemProps) {
  const { addItem } = useCartStore();
  const { toast } = useToast();
  const [isAdding, setIsAdding] = useState(false);

  const handleAddToCart = async () => {
    setIsAdding(true);
    
    try {
      await addItem(
        {
          id: `${item.id}-${Date.now()}`, // Unique cart item ID
          menuItemId: item.id,
          name: item.name || "",
          nameAr: item.nameAr,
          price: item.price,
          image: item.image,
        },
        restaurant.id,
        restaurant.nameAr,
        restaurant.deliveryFee
      );

      toast({
        title: "تمت الإضافة للسلة",
        description: `تم إضافة ${item.nameAr} إلى سلة التسوق`,
      });
    } catch (error) {
      toast({
        title: "خطأ في الإضافة",
        description: "حدث خطأ أثناء إضافة العنصر للسلة",
        variant: "destructive",
      });
    } finally {
      setIsAdding(false);
    }
  };

  return (
    <Card className={`p-4 ${item.isSpecialOffer ? 'bg-primary/5 border-primary/20' : ''}`}>
      <div className="flex justify-between items-start">
        <div className="flex-1">
          {item.isSpecialOffer && (
            <div className="flex items-center space-x-reverse space-x-2 mb-2">
              <Badge className="bg-primary text-primary-foreground" data-testid={`badge-special-offer-${item.id}`}>
                عرض خاص
              </Badge>
              {item.originalPrice && (
                <span className="text-xs text-green-600 font-medium" data-testid={`text-savings-${item.id}`}>
                  توفير {(item.originalPrice - item.price).toLocaleString()} ر.ي
                </span>
              )}
            </div>
          )}
          
          <h3 className="font-semibold mb-1" data-testid={`text-item-name-${item.id}`}>
            {item.nameAr}
          </h3>
          
          {item.descriptionAr && (
            <p className="text-sm text-muted-foreground mb-2" data-testid={`text-item-description-${item.id}`}>
              {item.descriptionAr}
            </p>
          )}
          
          <div className="flex items-center space-x-reverse space-x-2">
            <p className="text-lg font-bold text-primary" data-testid={`text-item-price-${item.id}`}>
              {item.price.toLocaleString()} ر.ي
            </p>
            {item.originalPrice && item.originalPrice > item.price && (
              <p className="text-sm text-muted-foreground line-through" data-testid={`text-original-price-${item.id}`}>
                {item.originalPrice.toLocaleString()} ر.ي
              </p>
            )}
          </div>
        </div>
        
        {item.image && (
          <img 
            src={item.image}
            alt={item.nameAr}
            className="w-20 h-16 object-cover rounded-lg mr-4"
            data-testid={`img-item-${item.id}`}
          />
        )}
      </div>
      
      {item.isSpecialOffer ? (
        <Button
          className="w-full mt-3 font-medium"
          onClick={handleAddToCart}
          disabled={isAdding || !item.isAvailable}
          data-testid={`button-add-special-${item.id}`}
        >
          {isAdding ? (
            <>
              <i className="fas fa-spinner fa-spin ml-2"></i>
              جاري الإضافة...
            </>
          ) : !item.isAvailable ? (
            "غير متوفر"
          ) : (
            "إضافة للسلة"
          )}
        </Button>
      ) : (
        <div className="flex justify-end mt-2">
          <Button
            size="sm"
            onClick={handleAddToCart}
            disabled={isAdding || !item.isAvailable}
            data-testid={`button-add-item-${item.id}`}
          >
            {isAdding ? (
              <i className="fas fa-spinner fa-spin"></i>
            ) : !item.isAvailable ? (
              "غير متوفر"
            ) : (
              <i className="fas fa-plus"></i>
            )}
          </Button>
        </div>
      )}
    </Card>
  );
}
